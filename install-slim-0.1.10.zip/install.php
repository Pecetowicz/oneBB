<!DOCTYPE html>
<html>
<head>
<style>
body {
    background-color: #f8f9fa;
}
.center {
  text-align: center;
  margin: auto;
  width: 50%;
  border: 1px solid black;
  border-radius: 25px;
  padding: 10px;
  background-color: white;
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
.btn {
 padding:4px 16px;
 text-align:center;
 text-decoration:none;
 display:inline-block;
 font-size:14px;
 -webkit-transition-duration:.4s;
 transition-duration:.4s;
 cursor:pointer;
 border-radius:4px;
 background-color:transparent;
 color:#000;
 border:2px solid #555
}
.btn:hover {
 background-color:#555;
 color:#fff
}
.message {
 margin:1em;
 padding:1em;
 border-radius:4px;
 color:#f0f0f0;
 font-weight:700;
 text-align:center
}
.green {
 background:#03a679
}
.red {
 background:#e93f23
}
</style>
</head>
<body>

<div class="center">
  <h2>Boards Forum Software Installation Wizard</h2>
  <hr>
  <?php 
    $c = 0;
    if(isset($_GET['download'])) {
        if($_GET['download'] === '1') {
            download();
        }
    }
    $check = checkReq();
    echo '<div>
    <table>
    <tr><th>
    PHP: '. $check['php'] . '</th>';
    if ($check['php_check'] === true ) {
        echo '<th><strong style="color: green">OK</strong></th>';
        $c++;
    } else {
        echo '<th><strong style="color: RED">FAIL</strong></th>';
    }
    echo '</tr><tr><th>GD lib</th>';
    if ($check['gd'] === true ) {
        echo '<th><strong style="color: green">OK</strong></th>';
        $c++;
    } else {
        echo '</tr><th><strong style="color: RED">FAIL</strong></th>';
    }
    echo '</tr><tr><th>CURL lib</th>';
    if ($check['gd'] === true ) {
        echo '<th><strong style="color: green">OK</strong></th>';
        $c++;
    } else {
        echo '<th><strong style="color: RED">FAIL</strong></th>';
    }
    echo '</tr><tr><th>ZIP lib</th>';
    if ($check['zip'] === true ) {
        echo '<th><strong style="color: green">OK</strong></th>';
        $c++;
    } else {
        echo '<th><strong style="color: RED">FAIL</strong></th>';
    }
    echo '</tr></table></div>';

if ($c == 4) {
     echo '<span class="message green" style="width:93%; display: flex; font-weight: bold;">Serwer spałnia wamagania Boards!</span>
     <a href="?download=1" class="btn right">Pobierz</a>'; 
} else {
    echo '<span class="message red" style="width:93%; display: flex; font-weight: bold;">Serwer nie spałnia wymagań minimalnych!</span>';
}
 ?>
</div>

</body>
</html>

<?php

function checkReq()
{
    extension_loaded('gd') ? $gd = true : $gd = false;
    extension_loaded('zip')? $zip = true : $zip = false;
    $phpv = phpversion();
    $php = explode('.', $phpv);
    $php_check = false;
    if (intval($php[0]) === 8) {
       $php_check = true;
    }    
    if (intval($php[0]) === 7 && intval($php[1]) === 4) {
       $php_check = true ;
    }
    
    $curl =  function_exists('curl_version');
    $check = [
        'php' => $phpv,
        'php_check' => $php_check,
        'gd' => $gd,
        'curl' => $curl,
        'zip' => $zip
    ];
    
       
    return $check;
}

function download()
{

    $output_filename = __DIR__ ."/last.zip";
    $host = "https://boards.s89.eu/forum/download/packages/last.zip";
    if (!file_exists($output_filename)) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $host);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_AUTOREFERER, false);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $result = curl_exec($ch);
        curl_close($ch);
        $fp = fopen($output_filename, 'w');
        fwrite($fp, $result);
        fclose($fp);
    }

    if (file_exists($output_filename)) {
        $zip = new ZipArchive;
        $res = $zip->open($output_filename);
        if ($res === TRUE) {
          $zip->extractTo(__DIR__ .'/');
          $zip->close();
            $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $actual_link = explode('?', $actual_link)[0];
            if (strpos($actual_link, 'php')) {
                $actual_link = substr($actual_link, 0, -11);
            }
            $actual_link .= 'install';
            unlink($output_filename);
            unlink('install.php');
            header('Location: ' . $actual_link);
            die();
        } else {
          echo 'ERR!';
          @unlink($output_filenam);
        }
        
    }   
    
    
}

?>
